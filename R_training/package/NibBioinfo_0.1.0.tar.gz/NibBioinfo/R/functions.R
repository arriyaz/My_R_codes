#####################
#' A Function to find start and stop codons and their position
#' @export
#' @param windowsize Which size of sliding window use
#' @param inputseq Specify the sequence
#' @param pointcolor Specify the color of the points

gcSlidingWindowPlot <- function(windowsize, inputseq, pointcolor)
{
  # require(seqinr)
  starts <- seq(1, length(inputseq)-windowsize, by = windowsize)
  n <- length(starts)    # Find the length of the vector "starts"
  chunkGCs <- numeric(n) # Make a vector of the same length as vector "starts", but just containing zeroes
  for (i in 1:n) {
    chunk <- inputseq[starts[i]:(starts[i]+windowsize-1)]
    chunkGC <- seqinr::GC(chunk)
    chunkGCs[i] <- chunkGC
  }

  # get gc value for last windows
  lastvalue <- seqinr::GC(inputseq[starts[length(starts)]+windowsize:length(inputseq)])

  # add the value to chunkGCs vector
  gccontents <- append(chunkGCs, lastvalue)

  # add start position of last window to starts vector
  starts <- append(starts, starts[length(starts)]+windowsize)

  # print the gc contents
  print(gccontents)


  # plot the results
  plot(starts, gccontents, type="l", xlab="Nucleotide start position", ylab="GC content")
  # plot points on top of the graph
  points(starts,gccontents, pch=19, col = pointcolor)
}




########################

#' A Function to get sequence from NCBI
#' @param accession Input the accession number
#' @export

getNcbiSeq <- function(accession)
{
  # require("seqinr") # this function requires the SeqinR R package
  # first find which ACNUC database the accession is stored in:
  dbs <- c("genbank","refseq","refseqViruses","bacterial")
  numdbs <- length(dbs)
  for (i in 1:numdbs)
  {
    db <- dbs[i]
    seqinr::choosebank(db)
    # check if the sequence is in ACNUC database 'db':
    resquery <- try(query(".tmpquery", paste("AC=", accession)), silent = TRUE)
    if (!(inherits(resquery, "try-error")))
    {
      queryname <- "query2"
      thequery <- paste("AC=",accession,sep="")
      seqinr::query(`queryname`,`thequery`)
      # see if a sequence was retrieved:
      seq <- seqinr::getSequence(resquery$req[[1]])
      seqinr::closebank()
      return(seq)
    }
    seqinr::closebank()
  }
  print(paste("ERROR: accession",accession,"was not found"))
}



###########################################



#' A Function to find start and stop codons and their position
#' @export
#' @param seq sequence object

StartsAndStops <- function(seq)
{
  # require(Biostrings)

  # Define a vector with the sequences of potential start and stop codons
  codons <- c("atg", "taa", "tag", "tga")

  # Find the number of occurrences of each type of potential start or stop codon
  for (x in 1:4)
  {
    codon <- codons[x]

    # Find all occurrences of codon "codon" in sequence "seq"
    occurrences <- Biostrings::matchPattern(codon, seq)

    # Find the start positions of all occurrences of "codon" in sequence "seq"
    codonpositions <- attr(IRanges::ranges(occurrences), "start")

    # Find the total number of potential start and stop codons in sequence "seq"
    numoccurrences <- length(codonpositions)

    if (x == 1)
    {
      # Make a copy of vector "codonpositions" called "positions"
      positions <- codonpositions

      # Make a vector "types" containing "numoccurrences" copies of "codon"
      types <- rep(codon, numoccurrences)
    }
    else
    {
      # Add the vector "codonpositions" to the end of vector "positions":
      positions <- append(positions, codonpositions, after=length(positions))

      # Add the vector "rep(codon, numoccurrences)" to the end of vector "types":
      types <- append(types, rep(codon, numoccurrences), after=length(types))
    }
  }

  # Sort the vectors "positions" and "types" in order of position along the input sequence:
  indices <- order(positions)
  positions <- positions[indices]
  types <- types[indices]
  # Return a list variable including vectors "positions" and "types":
  mylist <- list(positions, types)
  return(mylist)
}

#################################

#' A Function to plot start and stop codon positions
#' @export
#' @param sequence sequence object

plotStartsAndStops <- function(sequence)
{
  # Define a vector with the sequences of potential start and stop codons
  codons <- c("atg", "taa", "tag", "tga")
  # Find the number of occurrences of each type of potential start or stop codon
  for (i in 1:4)
  {
    codon <- codons[i]

    # Find all occurrences of codon "codon" in sequence "sequence"
    occurrences <- Biostrings::matchPattern(codon, sequence)

    # Find the start positions of all occurrences of "codon" in sequence "sequence"
    codonpositions <- attr(IRanges::ranges(occurrences), "start")

    # Find the total number of potential start and stop codons in sequence "sequence"
    numoccurrences <- length(codonpositions)
    if (i == 1)
    {
      # Make a copy of vector "codonpositions" called "positions"
      positions   <- codonpositions
      # Make a vector "types" containing "numoccurrences" copies of "codon"
      types       <- rep(codon, numoccurrences)
    }
    else
    {
      # Add the vector "codonpositions" to the end of vector "positions":
      positions   <- append(positions, codonpositions, after=length(positions))
      # Add the vector "rep(codon, numoccurrences)" to the end of vector "types":
      types       <- append(types, rep(codon, numoccurrences), after=length(types))
    }
  }

  # Sort the vectors "positions" and "types" in order of position along the input sequence:
  indices <- order(positions)
  positions <- positions[indices]
  types <- types[indices]

  # Make a plot showing the positions of the start and stop codons in the input sequence:
  # Draw a line at y=0 from 1 to the length of the sequence:
  x  <- c(1,nchar(sequence))
  y <- c(0,0)

  plot(x, y, ylim=c(0,3), type="l", axes=FALSE, xlab="Nucleotide", ylab="Reading frame",
       main="Predicted start (red) and stop (blue) codons")

  # Add vertical lines
  segments(1,1,nchar(sequence),1)
  segments(1,2,nchar(sequence),2)


  # Add the x-axis at y=0:
  axis(1, pos=0)
  # Add the y-axis labels:
  text(0.5, 0.5, "+1")
  text(0.5, 1.5, "+2")
  text(0.5, 2.5, "+3")


  # Draw in each predicted start/stop codon:
  numcodons <- length(positions)
  for (i in 1:numcodons)
  {
    position <- positions[i]
    type <- types[i]
    remainder <- (position-1) %% 3
    if    (remainder == 0) # +1 reading frame
    {
      if (type == "atg") { segments(position,0,position,1,lwd=1,col="red") }
      else               { segments(position,0,position,1,lwd=1,col="blue")}
    }
    else if (remainder == 1)
    {
      if (type == "atg") { segments(position,1,position,2,lwd=1,col="red") }
      else               { segments(position,1,position,2,lwd=1,col="blue")}
    }
    else if (remainder == 2)
    {
      if (type == "atg") { segments(position,2,position,3,lwd=1,col="red") }
      else               { segments(position,2,position,3,lwd=1,col="blue")}
    }
  }
}



#######################
#' A Function to find the ORFs in a sequence
#' @export
#' @param sequence sequence object

findORFsinSeq <- function(sequence)
{
  # require(Biostrings)
  # Make vectors "positions" and "types" containing information on the positions of ATGs in the sequence:
  mylist <- StartsAndStops(sequence)
  positions <- mylist[[1]]
  types <- mylist[[2]]
  # Make vectors "orfstarts" and "orfstops" to store the predicted start and stop codons of ORFs
  orfstarts <- numeric()
  orfstops <- numeric()
  # Make a vector "orflengths" to store the lengths of the ORFs
  orflengths <- numeric()
  # Print out the positions of ORFs in the sequence:
  # Find the length of vector "positions"
  numpositions <- length(positions)
  # There must be at least one start codon and one stop codon to have an ORF.
  if (numpositions >= 2)
  {
    for (i in 1:(numpositions-1))
    {
      posi <- positions[i]
      typei <- types[i]
      found <- 0
      while (found == 0)
      {
        for (j in (i+1):numpositions)
        {
          posj  <- positions[j]
          typej <- types[j]
          posdiff <- posj - posi
          posdiffmod3 <- posdiff %% 3
          # Add in the length of the stop codon
          orflength <- posj - posi + 3
          if (typei == "atg" && (typej == "taa" || typej == "tag" || typej == "tga") && posdiffmod3 == 0)
          {
            # Check if we have already used the stop codon at posj+2 in an ORF
            numorfs <- length(orfstops)
            usedstop <- -1
            if (numorfs > 0)
            {
              for (k in 1:numorfs)
              {
                orfstopk <- orfstops[k]
                if (orfstopk == (posj + 2)) { usedstop <- 1 }
              }
            }
            if (usedstop == -1)
            {
              orfstarts <- append(orfstarts, posi, after=length(orfstarts))
              orfstops <- append(orfstops, posj+2, after=length(orfstops)) # Including the stop codon.
              orflengths <- append(orflengths, orflength, after=length(orflengths))
            }
            found <- 1
            break
          }
          if (j == numpositions) { found <- 1 }
        }
      }
    }
  }
  # Sort the final ORFs by start position:
  indices <- order(orfstarts)
  orfstarts <- orfstarts[indices]
  orfstops <- orfstops[indices]
  # Find the lengths of the ORFs that we have
  orflengths <- numeric()
  numorfs <- length(orfstarts)
  for (i in 1:numorfs)
  {
    orfstart <- orfstarts[i]
    orfstop <- orfstops[i]
    orflength <- orfstop - orfstart + 1
    orflengths <- append(orflengths,orflength,after=length(orflengths))
  }
  mylist <- as.data.frame(list(orfstarts, orfstops, orflengths))
  mylist <- as.data.frame(mylist)
  names(mylist) <- c("ORFstarts", "ORFstops", "ORFlengths")
  return(mylist)
}

#################

#' A Function to plot the ORFs positions sequence
#' @export
#' @param sequence sequence object
#'
plotORFsinSeq <- function(sequence)
{
  # Make vectors "positions" and "types" containing information on the positions of ATGs in the sequence:
  mylist <- StartsAndStops(sequence)
  positions <- mylist[[1]]
  types <- mylist[[2]]
  # Make vectors "orfstarts" and "orfstops" to store the predicted start and stop codons of ORFs
  orfstarts <- numeric()
  orfstops <- numeric()
  # Make a vector "orflengths" to store the lengths of the ORFs
  orflengths <- numeric()
  # Print out the positions of ORFs in the sequence:
  numpositions <- length(positions) # Find the length of vector "positions"
  # There must be at least one start codon and one stop codon to have an ORF.
  if (numpositions >= 2)
  {
    for (i in 1:(numpositions-1))
    {
      posi <- positions[i]
      typei <- types[i]
      found <- 0
      while (found == 0)
      {
        for (j in (i+1):numpositions)
        {
          posj <- positions[j]
          typej <- types[j]
          posdiff <- posj - posi
          posdiffmod3 <- posdiff %% 3
          orflength <- posj - posi + 3 # Add in the length of the stop codon
          if (typei == "atg" && (typej == "taa" || typej == "tag" || typej == "tga") && posdiffmod3 == 0)
          {
            # Check if we have already used the stop codon at posj+2 in an ORF
            numorfs <- length(orfstops)
            usedstop <- -1
            if (numorfs > 0)
            {
              for (k in 1:numorfs)
              {
                orfstopk <- orfstops[k]
                if (orfstopk == (posj + 2)) { usedstop <- 1 }
              }
            }
            if (usedstop == -1)
            {
              orfstarts <- append(orfstarts, posi, after=length(orfstarts))
              orfstops <- append(orfstops, posj+2, after=length(orfstops)) # Including the stop codon.
              orflengths <- append(orflengths, orflength, after=length(orflengths))
            }
            found <- 1
            break
          }
          if (j == numpositions) { found <- 1 }
        }
      }
    }
  }
  # Sort the final ORFs by start position:
  indices <- order(orfstarts)
  orfstarts <- orfstarts[indices]
  orfstops <- orfstops[indices]
  # Make a plot showing the positions of ORFs in the input sequence:
  # Draw a line at y=0 from 1 to the length of the sequence:
  x <- c(1,nchar(sequence))
  y <- c(0,0)
  plot(x, y, ylim=c(0,3), type="l", axes=FALSE, xlab="Nucleotide", ylab="Reading frame", main="Predicted ORFs")
  segments(1,1,nchar(sequence),1)
  segments(1,2,nchar(sequence),2)
  # Add the x-axis at y=0:
  axis(1, pos=0)
  # Add the y-axis labels:
  text(0.9,0.5,"+1")
  text(0.9,1.5,"+2")
  text(0.9,2.5,"+3")
  # Make a plot of the ORFs in the sequence:
  numorfs <- length(orfstarts)
  for (i in 1:numorfs)
  {
    orfstart <- orfstarts[i]
    orfstop <- orfstops[i]
    remainder <- (orfstart-1) %% 3
    if    (remainder == 0) # +1 reading frame
    {
      rect(orfstart,0,orfstop,1,col="cyan",border="black")
    }
    else if (remainder == 1)
    {
      rect(orfstart,1,orfstop,2,col="cyan",border="black")
    }
    else if (remainder == 2)
    {
      rect(orfstart,2,orfstop,3,col="cyan",border="black")
    }
  }
}


